package com.apps.michaeldow.projectdao.MainActivity.ChatFragment

import android.arch.lifecycle.ViewModel

class ChatViewModel : ViewModel() {



}