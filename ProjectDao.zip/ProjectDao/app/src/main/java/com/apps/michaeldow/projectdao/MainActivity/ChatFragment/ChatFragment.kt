package com.apps.michaeldow.projectdao.MainActivity.ChatFragment

import android.arch.lifecycle.ViewModel
import android.support.v4.app.Fragment

class ChatFragment : Fragment() {



}